﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HttpPhoneNumberParser
{
    public struct CallerId
    {
        public string phoneNumber;
        public string name;
    }
}
